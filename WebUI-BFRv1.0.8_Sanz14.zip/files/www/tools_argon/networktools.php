<?php
// Initialize variables for pre-checking
$checked_wifi = $checked_cell = $checked_bluetooth = $checked_nfc = $checked_wimax = false;
$network_choice = 'hotspot'; // Default value
$airplane_mode_enabled = false;
$message = '';

// Detect current state of radio settings
$current_radios = shell_exec("su -c 'settings get global airplane_mode_radios'");
$current_radios = explode(',', trim($current_radios));

$checked_cell = in_array('cell', $current_radios);
$checked_bluetooth = in_array('bluetooth', $current_radios);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['action'])) {
        $action = $_POST['action'];
        
        switch ($action) {
            case 'disable_airplane_mode':
                shell_exec("su -c 'settings put global airplane_mode_on 0'");
                shell_exec("su -c 'am broadcast -a android.intent.action.AIRPLANE_MODE --ez state false'");

                $enabled_radios = isset($_POST['enabled_radios']) ? json_decode($_POST['enabled_radios'], true) : [];
                $radios_str = implode(',', $enabled_radios);
                shell_exec("su -c 'settings put global airplane_mode_radios \"$radios_str\"'");

                $message = "<div class='bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4'>Airplane mode disabled.</div>";
                $airplane_mode_enabled = false;
                break;

            case 'enable_airplane_mode':
                $enabled_radios = [];
                if (isset($_POST['cell'])) $enabled_radios[] = 'cell';
                if (isset($_POST['bluetooth'])) $enabled_radios[] = 'bluetooth';

                $radios_str = implode(',', $enabled_radios);
                $network_choice = $_POST['network_choice'] ?? 'hotspot';

                shell_exec("su -c 'settings put global airplane_mode_radios \"$radios_str\"'");
                shell_exec("su -c 'settings put global airplane_mode_on 1'");
                shell_exec("su -c 'am broadcast -a android.intent.action.AIRPLANE_MODE --ez state true'");

                if ($network_choice === 'wifi') {
                    shell_exec("su -c 'svc wifi enable'");
                    shell_exec("su -c 'svc wifi sethotspotenabled false'");
                } elseif ($network_choice === 'hotspot') {
                    shell_exec("su -c 'svc wifi sethotspotenabled true'");
                    shell_exec("su -c 'svc wifi disable'");
                }

                $message = "<div class='bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4'>Airplane mode enabled with selected radios. Network choice: $network_choice.</div>";
                
                $message .= "<script>
                    setTimeout(function() {
                        var xhttp = new XMLHttpRequest();
                        xhttp.open('POST', '', true);
                        xhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
                        xhttp.send('action=disable_airplane_mode&enabled_radios=".urlencode(json_encode($enabled_radios))."');
                    }, 5000);
                </script>";
                
                $airplane_mode_enabled = true;
                break;

            case 'update_radios':
                if (isset($_POST['bluetooth_control'])) {
                    shell_exec("su -c 'svc bluetooth enable'");
                } else {
                    shell_exec("su -c 'svc bluetooth disable'");
                }

                if (isset($_POST['wifi_control'])) {
                    shell_exec("su -c 'svc wifi enable'");
                } else {
                    shell_exec("su -c 'svc wifi disable'");
                }

                $message = "<div class='bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4'>Radio settings updated.</div>";
                break;

            case 'lock_band':
                if (isset($_POST['band_selection']) && !empty($_POST['band_selection'])) {
                    $band = $_POST['band_selection'];
                    $command_type = $_POST['command_type'] ?? 'standard';
                    $network_pref = $_POST['network_preference'] ?? '4g';
                    $debug_output = "";
                    
                    if (isset($_POST['set_network_pref']) && $network_pref) {
                        $network_value = 0;
                        switch ($network_pref) {
                            case '5g': $network_value = 26; break;
                            case '5g_standalone': $network_value = 27; break;
                            case '4g': $network_value = 9; break;
                            case '4g_only': $network_value = 11; break;
                            case '3g': $network_value = 0; break;
                            case '3g_only': $network_value = 2; break;
                            case '2g': $network_value = 1; break;
                        }
                        shell_exec("su -c 'settings put global preferred_network_mode $network_value'");
                        $debug_output .= "Set network preference: $network_pref (value: $network_value)\n";
                    }
                    
                    if (isset($_POST['force_5g_mode']) && !empty($_POST['force_5g_mode'])) {
                        $mode_5g = $_POST['force_5g_mode'];
                        switch ($mode_5g) {
                            case 'nsa':
                                shell_exec("su -c 'settings put global nr_nsa_allowed_networks 15'");
                                shell_exec("su -c 'settings put global nr_sa_allowed_networks 0'");
                                $debug_output .= "Force 5G NSA mode enabled\n";
                                break;
                            case 'sa':
                                shell_exec("su -c 'settings put global nr_nsa_allowed_networks 0'");
                                shell_exec("su -c 'settings put global nr_sa_allowed_networks 15'");
                                $debug_output .= "Force 5G SA mode enabled\n";
                                break;
                            case 'both':
                                shell_exec("su -c 'settings put global nr_nsa_allowed_networks 15'");
                                shell_exec("su -c 'settings put global nr_sa_allowed_networks 15'");
                                $debug_output .= "Both 5G NSA and SA modes enabled\n";
                                break;
                        }
                    }
                    
                    $is_nr_band = strpos($band, 'n') === 0;
                    $band_number = $is_nr_band ? substr($band, 1) : $band;
                    
                    if (isset($_POST['provider_preset']) && !empty($_POST['provider_preset'])) {
                        $provider = $_POST['provider_preset'];
                        $band_values = [];
                        
                        switch ($provider) {
                            case 'telkomsel': $band_values = ['3', '8', '40']; break;
                            case 'xl': $band_values = ['1', '3', '8', '40']; break;
                            case 'indosat': $band_values = ['1', '3', '8']; break;
                            case 'tri': $band_values = ['1', '8', '40']; break;
                            case 'smartfren': $band_values = ['5', '40', 'n40']; break;
                        }
                        
                        if (!empty($band_values)) {
                            $band = implode(',', $band_values);
                            $command_type = 'multiple_bands';
                            $debug_output .= "Using provider preset: $provider, bands: $band\n";
                        }
                    }
                    
                    if (isset($_POST['set_earfcn']) && !empty($_POST['earfcn_value'])) {
                        $earfcn = $_POST['earfcn_value'];
                        if ($is_nr_band) {
                            $result_earfcn = shell_exec("su -c 'service call qcrilhook 35 i32 1 i32 $earfcn'");
                            $debug_output .= "Set NR-ARFCN to $earfcn: $result_earfcn\n";
                        } else {
                            $result_earfcn = shell_exec("su -c 'service call phone 29 i32 1 i32 $earfcn'");
                            $debug_output .= "Set EARFCN to $earfcn: $result_earfcn\n";
                        }
                    }
                    
                    if (isset($_POST['lock_cell_id']) && !empty($_POST['cell_id_value'])) {
                        $cell_id = $_POST['cell_id_value'];
                        $result_cell = shell_exec("su -c 'service call phone 28 i32 1 i32 $cell_id'");
                        $debug_output .= "Lock to Cell ID $cell_id: $result_cell\n";
                    }
                    
                    switch ($command_type) {
                        case 'standard':
                            if ($is_nr_band) {
                                $result = shell_exec("su -c 'service call phone 27 i32 5 i32 $band_number'");
                            } else {
                                $result = shell_exec("su -c 'service call phone 27 i32 1 i32 $band_number'");
                            }
                            $debug_output .= "Command: service call phone 27 i32 ".($is_nr_band?"5":"1")." i32 $band_number\n";
                            break;
                        
                        case 'qcrilhook':
                            if ($is_nr_band) {
                                $result = shell_exec("su -c 'service call qcrilhook 33 i32 1 i32 $band_number'");
                            } else {
                                $result = shell_exec("su -c 'service call qcrilhook 31 i32 1 i32 $band_number'");
                            }
                            $debug_output .= "Command: service call qcrilhook ".($is_nr_band?"33":"31")." i32 1 i32 $band_number\n";
                            break;
                        
                        case 'qcrilnr':
                            $result = shell_exec("su -c 'service call qcrilnr 1 i32 1 i32 $band_number'");
                            $debug_output .= "Command: service call qcrilnr 1 i32 1 i32 $band_number\n";
                            break;
                        
                        case 'alternative':
                            $result = shell_exec("su -c 'service call phone 27 i32 3 i32 $band_number'");
                            $debug_output .= "Command: service call phone 27 i32 3 i32 $band_number\n";
                            break;
                        
                        case 'netmgr':
                            $result = shell_exec("su -c 'service call netmgr 3 i32 1 i32 $band_number'");
                            $debug_output .= "Command: service call netmgr 3 i32 1 i32 $band_number\n";
                            break;
                        
                        case 'atcommand':
                            if ($is_nr_band) {
                                $at_command = "AT+QNWPREFCFG=\"nr5g_band\",$band_number";
                            } else {
                                $at_command = "AT+QNWPREFCFG=\"lte_band\",$band_number";
                            }
                            $result = shell_exec("su -c 'echo \"$at_command\" > /dev/smd11'");
                            $debug_output .= "AT command: $at_command via /dev/smd11\n";
                            break;
                        
                        case 'multiple_bands':
                            $bands = explode(',', $band);
                            $lte_bands = [];
                            $nr_bands = [];
                            
                            foreach ($bands as $b) {
                                if (strpos($b, 'n') === 0) {
                                    $nr_bands[] = substr($b, 1);
                                } else {
                                    $lte_bands[] = $b;
                                }
                            }
                            
                            if (!empty($lte_bands)) {
                                $band_mask = 0;
                                foreach ($lte_bands as $b) {
                                    $band_mask |= (1 << ((int)$b - 1));
                                }
                                $result = shell_exec("su -c 'service call phone 27 i32 2 i64 $band_mask'");
                                $debug_output .= "Lock multiple 4G bands (".implode(",",$lte_bands).") with mask: $band_mask\n";
                            }
                            
                            if (!empty($nr_bands)) {
                                $nr_mask = 0;
                                foreach ($nr_bands as $b) {
                                    $nr_mask |= (1 << ((int)$b - 1));
                                }
                                $result2 = shell_exec("su -c 'service call qcrilhook 33 i32 2 i64 $nr_mask'");
                                $debug_output .= "Lock multiple 5G bands (".implode(",",$nr_bands).") with mask: $nr_mask\n";
                                $result .= $result2;
                            }
                            break;
                    }
                    
                    $config = [
                        'band' => $band,
                        'command_type' => $command_type,
                        'network_pref' => $network_pref,
                        'timestamp' => date('Y-m-d H:i:s')
                    ];
                    file_put_contents('/data/local/tmp/band_config.json', json_encode($config));
                    $debug_output .= "Configuration saved to /data/local/tmp/band_config.json\n";
                    
                    if (isset($_POST['restart_radio']) && $_POST['restart_radio'] == 1) {
                        shell_exec("su -c 'svc data disable'");
                        sleep(1);
                        shell_exec("su -c 'svc data enable'");
                        $debug_output .= "Radio restarted to apply changes\n";
                    }
                    
                    $message = "<div class='bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4'>Band $band locked with method: $command_type.</div>";
                    $message .= "<div class='bg-blue-100 border-l-4 border-blue-500 text-blue-700 p-4 mb-4'><strong>Debug Info:</strong><pre>".htmlspecialchars($debug_output)."</pre></div>";
                    $message .= "<div class='bg-orange-100 border-l-4 border-orange-500 text-orange-700 p-4 mb-4'><strong>Command Output:</strong><pre>".htmlspecialchars($result ?? "No output")."</pre></div>";
                } else {
                    $message = "<div class='bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-4'>Please select a band first!</div>";
                }
                break;

            case 'unlock_band':
                $command_type = $_POST['command_type'] ?? 'standard';
                $debug_output = "";
                
                switch ($command_type) {
                    case 'standard':
                        $result = shell_exec("su -c 'service call phone 27 i32 0 i32 0'");
                        $debug_output .= "Command: service call phone 27 i32 0 i32 0\n";
                        break;
                    case 'qcrilhook':
                        $result = shell_exec("su -c 'service call qcrilhook 31 i32 0 i32 0'");
                        $result .= shell_exec("su -c 'service call qcrilhook 33 i32 0 i32 0'");
                        $debug_output .= "Commands: service call qcrilhook 31/33 i32 0 i32 0\n";
                        break;
                    case 'qcrilnr':
                        $result = shell_exec("su -c 'service call qcrilnr 1 i32 0 i32 0'");
                        $debug_output .= "Command: service call qcrilnr 1 i32 0 i32 0\n";
                        break;
                    case 'alternative':
                        $result = shell_exec("su -c 'service call phone 27 i32 0 i32 0'");
                        $debug_output .= "Command: service call phone 27 i32 0 i32 0\n";
                        break;
                    case 'netmgr':
                        $result = shell_exec("su -c 'service call netmgr 3 i32 0 i32 0'");
                        $debug_output .= "Command: service call netmgr 3 i32 0 i32 0\n";
                        break;
                    case 'atcommand':
                        $result = shell_exec("su -c 'echo \"AT+QNWPREFCFG=\\\"lte_band\\\",0\" > /dev/smd11'");
                        $result .= shell_exec("su -c 'echo \"AT+QNWPREFCFG=\\\"nr5g_band\\\",0\" > /dev/smd11'");
                        $debug_output .= "AT commands to reset LTE and 5G bands\n";
                        break;
                    case 'multiple_bands':
                        $result = shell_exec("su -c 'service call phone 27 i32 2 i64 0'");
                        $result .= shell_exec("su -c 'service call qcrilhook 33 i32 2 i64 0'");
                        $debug_output .= "Commands to unlock multiple bands\n";
                        break;
                }
                
                shell_exec("su -c 'settings delete global preferred_network_mode'");
                shell_exec("su -c 'settings delete global nr_nsa_allowed_networks'");
                shell_exec("su -c 'settings delete global nr_sa_allowed_networks'");
                shell_exec("su -c 'service call phone 29 i32 0 i32 0'");
                shell_exec("su -c 'service call qcrilhook 35 i32 0 i32 0'");
                shell_exec("su -c 'service call phone 28 i32 0 i32 0'");
                $debug_output .= "Reset all network settings\n";
                
                if (isset($_POST['restart_radio']) && $_POST['restart_radio'] == 1) {
                    shell_exec("su -c 'svc data disable'");
                    sleep(1);
                    shell_exec("su -c 'svc data enable'");
                    $debug_output .= "Radio restarted to apply changes\n";
                }
                
                shell_exec("su -c 'rm -f /data/local/tmp/band_config.json'");
                shell_exec("su -c 'rm -f /data/local/tmp/band_monitor.flag'");
                $debug_output .= "Removed configuration and monitoring files\n";
                
                $message = "<div class='bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4'>Band unlocked with method: $command_type.</div>";
                $message .= "<div class='bg-blue-100 border-l-4 border-blue-500 text-blue-700 p-4 mb-4'><strong>Debug Info:</strong><pre>".htmlspecialchars($debug_output)."</pre></div>";
                $message .= "<div class='bg-orange-100 border-l-4 border-orange-500 text-orange-700 p-4 mb-4'><strong>Command Output:</strong><pre>".htmlspecialchars($result ?? "No output")."</pre></div>";
                break;

            case 'get_network_info':
                $info = [];
                $info['Signal Strength'] = shell_exec("su -c 'dumpsys telephony.registry | grep mSignalStrength'");
                $info['Network Type'] = shell_exec("su -c 'dumpsys telephony.registry | grep mDataNetworkType'");
                $info['Operator'] = shell_exec("su -c 'dumpsys telephony.registry | grep mOperatorAlphaShort'");
                $info['Service State'] = shell_exec("su -c 'dumpsys telephony.registry | grep mServiceState'");
                $info['Cell Info'] = shell_exec("su -c 'dumpsys telephony.registry | grep mCellInfo'");
                $info['Serving Cell'] = shell_exec("su -c 'dumpsys telephony.registry | grep -A 10 \"mCellIdentity\"'");
                $info['Band Info'] = shell_exec("su -c 'service call phone 27 i32 4 i32 0'");
                $info['EARFCN'] = shell_exec("su -c 'dumpsys telephony.registry | grep -i earfcn'");
                $info['Current Band Locks'] = shell_exec("su -c 'getprop | grep band'");
                $info['Modem Info'] = shell_exec("su -c 'getprop | grep -E \"gsm.version.baseband|gsm.operator.alpha|gsm.network.type\"'");
                $info['IP Address'] = shell_exec("su -c 'ip addr show | grep -E \"wlan|rmnet\"'");
                $info['DNS Settings'] = shell_exec("su -c 'getprop | grep dns'");
                
                $info_html = "<div class='bg-gray-800 text-white p-4 rounded-lg mb-4'>";
                $info_html .= "<h3 class='text-lg font-semibold mb-2'>Network Information</h3>";
                $info_html .= "<div class='overflow-auto max-h-96'>";
                foreach ($info as $key => $value) {
                    $info_html .= "<div class='mb-3'><strong class='text-blue-300'>$key:</strong><pre class='text-sm'>".htmlspecialchars($value)."</pre></div>";
                }
                $info_html .= "</div></div>";
                
                if (file_exists("/data/local/tmp/signal_monitor.log")) {
                    $signal_log = shell_exec("su -c 'tail -n 20 /data/local/tmp/signal_monitor.log'");
                    $info_html .= "<div class='bg-gray-800 text-white p-4 rounded-lg'>";
                    $info_html .= "<h3 class='text-lg font-semibold mb-2'>Signal Monitor Log (last 20 entries)</h3>";
                    $info_html .= "<pre class='text-sm'>".htmlspecialchars($signal_log)."</pre></div>";
                }
                
                $message = $info_html;
                break;

            case 'advanced_modem_control':
                $modem_command = $_POST['modem_command'] ?? '';
                $debug_output = "";
                $result = "";
                
                switch ($modem_command) {
                    case 'reset_modem':
                        $result = shell_exec("su -c 'svc data disable && sleep 2 && svc data enable'");
                        $debug_output .= "Modem reset by disabling and enabling data\n";
                        break;
                    
                    case 'force_reconnect':
                        $result = shell_exec("su -c 'settings put global airplane_mode_on 1'");
                        shell_exec("su -c 'am broadcast -a android.intent.action.AIRPLANE_MODE --ez state true'");
                        sleep(2);
                        $result .= shell_exec("su -c 'settings put global airplane_mode_on 0'");
                        shell_exec("su -c 'am broadcast -a android.intent.action.AIRPLANE_MODE --ez state false'");
                        $debug_output .= "Force reconnect using airplane mode toggle\n";
                        break;
                    
                    case 'clear_radio_logs':
                        $result = shell_exec("su -c 'rm -f /data/log/radio/* /data/vendor/radio/logs/* /data/vendor/radio/*log*'");
                        $debug_output .= "Cleared radio logs\n";
                        break;
                    
                    case 'modem_diagnostics':
                        $result = "== Modem Info ==\n";
                        $result .= shell_exec("su -c 'getprop | grep radio'") . "\n";
                        $result .= shell_exec("su -c 'getprop | grep gsm'") . "\n";
                        $result .= "== Signal Info ==\n";
                        $result .= shell_exec("su -c 'dumpsys telephony.registry | grep -E \"mSignalStrength|mDataNetworkType|mOperator\"'");
                        $debug_output .= "Collected modem diagnostic information\n";
                        break;
                    
                    case 'set_fast_dormancy':
                        $fd_status = isset($_POST['fast_dormancy']) ? 1 : 0;
                        $result = shell_exec("su -c 'settings put global cust_fast_dormancy $fd_status'");
                        $debug_output .= "Fast dormancy ".($fd_status?"enabled":"disabled")."\n";
                        break;
                    
                    case 'set_data_roaming':
                        $roaming_status = isset($_POST['data_roaming']) ? 1 : 0;
                        $result = shell_exec("su -c 'settings put global data_roaming $roaming_status'");
                        $debug_output .= "Data roaming ".($roaming_status?"enabled":"disabled")."\n";
                        break;
                    
                    case 'network_logging':
                        $log_file = "/data/local/tmp/network_log_".date("Ymd_His").".txt";
                        $result = "== Network Info ==\n";
                        $result .= shell_exec("su -c 'ip addr'") . "\n";
                        $result .= shell_exec("su -c 'ip route'") . "\n";
                        $result .= "== DNS Info ==\n";
                        $result .= shell_exec("su -c 'getprop | grep dns'") . "\n";
                        shell_exec("su -c 'echo \"$result\" > $log_file'");
                        $debug_output .= "Network log saved to $log_file\n";
                        break;
                }
                
                $message = "<div class='bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4'>Modem command executed: $modem_command.</div>";
                $message .= "<div class='bg-blue-100 border-l-4 border-blue-500 text-blue-700 p-4 mb-4'><strong>Debug Info:</strong><pre>".htmlspecialchars($debug_output)."</pre></div>";
                $message .= "<div class='bg-orange-100 border-l-4 border-orange-500 text-orange-700 p-4 mb-4'><strong>Command Output:</strong><pre>".htmlspecialchars($result ?? "No output")."</pre></div>";
                break;

            case 'kernel_tweaks':
                $tweak_type = $_POST['tweak_type'] ?? '';
                $debug_output = "";
                $result = "";
                
                switch ($tweak_type) {
                    case 'tcp_optimize':
                        shell_exec("su -c 'echo 1 > /proc/sys/net/ipv4/tcp_tw_reuse'");
                        shell_exec("su -c 'echo 0 > /proc/sys/net/ipv4/tcp_timestamps'");
                        shell_exec("su -c 'echo 1 > /proc/sys/net/ipv4/tcp_sack'");
                        $result = "TCP optimized for better network performance";
                        $debug_output .= "Set TCP kernel parameters\n";
                        break;
                    
                    case 'network_buffer':
                        shell_exec("su -c 'echo 4194304 > /proc/sys/net/core/rmem_max'");
                        shell_exec("su -c 'echo 4194304 > /proc/sys/net/core/wmem_max'");
                        $result = "Network buffers increased for better throughput";
                        $debug_output .= "Increased network buffer sizes\n";
                        break;
                    
                    case 'dns_optimize':
                        shell_exec("su -c 'setprop net.dns1 8.8.8.8'");
                        shell_exec("su -c 'setprop net.dns2 8.8.4.4'");
                        $result = "DNS optimized using Google DNS";
                        $debug_output .= "Set DNS to Google (8.8.8.8, 8.8.4.4)\n";
                        break;
                    
                    case 'cloudflare_dns':
                        shell_exec("su -c 'setprop net.dns1 1.1.1.1'");
                        shell_exec("su -c 'setprop net.dns2 1.0.0.1'");
                        $result = "DNS optimized using Cloudflare DNS (1.1.1.1)";
                        $debug_output .= "Set DNS to Cloudflare (1.1.1.1, 1.0.0.1)\n";
                        break;
                    
                    case 'quad9_dns':
                        shell_exec("su -c 'setprop net.dns1 9.9.9.9'");
                        shell_exec("su -c 'setprop net.dns2 149.112.112.112'");
                        $result = "DNS optimized using Quad9 DNS (9.9.9.9)";
                        $debug_output .= "Set DNS to Quad9 (9.9.9.9, 149.112.112.112)\n";
                        break;
                    
                    case 'custom_dns':
                        $primary_dns = $_POST['primary_dns'] ?? '';
                        $secondary_dns = $_POST['secondary_dns'] ?? '';
                        
                        if (filter_var($primary_dns, FILTER_VALIDATE_IP)) {
                            shell_exec("su -c 'setprop net.dns1 $primary_dns'");
                            $debug_output .= "Primary DNS set to: $primary_dns\n";
                        }
                        if (filter_var($secondary_dns, FILTER_VALIDATE_IP)) {
                            shell_exec("su -c 'setprop net.dns2 $secondary_dns'");
                            $debug_output .= "Secondary DNS set to: $secondary_dns\n";
                        }
                        $result = "Custom DNS settings applied";
                        break;
                    
                    case 'reset_tweaks':
                        shell_exec("su -c 'echo 0 > /proc/sys/net/ipv4/tcp_tw_reuse'");
                        shell_exec("su -c 'echo 1 > /proc/sys/net/ipv4/tcp_timestamps'");
                        shell_exec("su -c 'setprop net.dns1 \"\"'");
                        shell_exec("su -c 'setprop net.dns2 \"\"'");
                        $result = "Network settings reset to defaults";
                        $debug_output .= "Reset all kernel tweaks to default\n";
                        break;
                }
                
                $message = "<div class='bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4'>Kernel tweak applied: $tweak_type.</div>";
                $message .= "<div class='bg-blue-100 border-l-4 border-blue-500 text-blue-700 p-4 mb-4'><strong>Debug Info:</strong><pre>".htmlspecialchars($debug_output)."</pre></div>";
                $message .= "<div class='bg-orange-100 border-l-4 border-orange-500 text-orange-700 p-4 mb-4'><strong>Result:</strong><pre>".htmlspecialchars($result)."</pre></div>";
                break;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Network Tools</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        .tab-content {
            display: none;
        }
        .tab-content.active {
            display: block;
        }
        .nav-bg {
            background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%);
        }
        pre {
            background-color: #1e293b;
            color: #f8fafc;
            padding: 1rem;
            border-radius: 0.375rem;
            overflow-x: auto;
            font-family: 'Courier New', monospace;
            font-size: 0.875rem;
        }
        .card {
            transition: all 0.3s ease;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }
        .card:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
        }
        .tab-button {
            transition: all 0.2s ease;
            position: relative;
        }
        .tab-button:after {
            content: '';
            position: absolute;
            bottom: -1px;
            left: 0;
            width: 0;
            height: 2px;
            background-color: #4f46e5;
            transition: width 0.3s ease;
        }
        .tab-button:hover:after {
            width: 100%;
        }
        .tab-button.active {
            color: #4f46e5;
        }
        .tab-button.active:after {
            width: 100%;
        }
    </style>
</head>
<body class="bg-gray-50 min-h-screen">
    <!-- Navbar -->
    <nav class="nav-bg text-white shadow-md">
        <div class="container mx-auto px-4 py-3 flex justify-between items-center">
            <div class="flex items-center space-x-2">
                <i class="fas fa-network-wired text-xl"></i>
                <span class="text-xl font-semibold">Network Tools</span>
            </div>
            <div class="hidden md:flex space-x-4">
                <a href="dashboard.php" class="hover:text-gray-200 flex items-center">
                    <i class="fas fa-tachometer-alt mr-2"></i> Dashboard
                </a>
                <a href="settings.php" class="hover:text-gray-200 flex items-center">
                    <i class="fas fa-cog mr-2"></i> Settings
                </a>
                <a href="../auth/logout.php" class="hover:text-gray-200 flex items-center">
                    <i class="fas fa-sign-out-alt mr-2"></i> Logout
                </a>
            </div>
        </div>
    </nav>

    <div class="container mx-auto px-4 py-6">
        <!-- Status Badges -->
        <div class="flex flex-wrap gap-2 mb-6">
            <span class="bg-purple-600 text-white px-3 py-1 rounded-full text-sm font-medium">
                <i class="fas fa-shield-alt mr-1"></i> Root Access: Active
            </span>
            <span class="bg-gray-600 text-white px-3 py-1 rounded-full text-sm font-medium">
                <i class="fas fa-wifi mr-1"></i> Network: <?php echo shell_exec("su -c 'getprop gsm.network.type'") ?: 'Unknown'; ?>
            </span>
            <span class="bg-indigo-600 text-white px-3 py-1 rounded-full text-sm font-medium">
                <i class="fas fa-signal mr-1"></i> Signal: <?php echo shell_exec("su -c \"dumpsys telephony.registry | grep mSignalStrength | head -n1 | awk '{print \\$2}'\"") ?: 'Unknown'; ?>
            </span>
            <span class="bg-teal-600 text-white px-3 py-1 rounded-full text-sm font-medium">
                <i class="fas fa-sim-card mr-1"></i> Operator: <?php echo shell_exec("su -c 'getprop gsm.sim.operator.alpha'") ?: 'Unknown'; ?>
            </span>
        </div>

        <!-- Tabs Navigation -->
        <div class="border-b border-gray-200 mb-6">
            <nav class="flex flex-wrap space-x-8">
                <button onclick="switchTab('tab-lock-band')" class="py-4 px-1 font-medium text-sm tab-button active border-b-2 border-indigo-600 text-indigo-600">
                    <i class="fas fa-network-wired mr-1"></i> Lock Band
                </button>
                <button onclick="switchTab('tab-modem-control')" class="py-4 px-1 font-medium text-sm tab-button border-b-2 border-transparent hover:text-indigo-600">
                    <i class="fas fa-microchip mr-1"></i> Modem Control
                </button>
                <button onclick="switchTab('tab-kernel-tweaks')" class="py-4 px-1 font-medium text-sm tab-button border-b-2 border-transparent hover:text-indigo-600">
                    <i class="fas fa-cogs mr-1"></i> Kernel Tweaks
                </button>
                <button onclick="switchTab('tab-radio-control')" class="py-4 px-1 font-medium text-sm tab-button border-b-2 border-transparent hover:text-indigo-600">
                    <i class="fas fa-broadcast-tower mr-1"></i> Radio Options
                </button>
            </nav>
        </div>

        <!-- Display messages if any -->
        <?php if (!empty($message)): ?>
            <div class="mb-6"><?php echo $message; ?></div>
        <?php endif; ?>

        <!-- Tab Contents -->
        <div id="tab-contents">
            <!-- Tab: Lock Band -->
            <div id="tab-lock-band" class="tab-content active">
                <div class="card bg-white p-6 mb-6 rounded-lg">
                    <div class="flex items-center mb-4">
                        <i class="fas fa-network-wired text-indigo-600 text-xl mr-2"></i>
                        <h2 class="text-xl font-semibold text-gray-800">Lock Band Jaringan</h2>
                    </div>
                    <p class="text-gray-600 mb-6">Kunci perangkat ke band jaringan tertentu untuk optimasi koneksi.</p>
                    
                    <form action="" method="post" class="space-y-4">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">Pilih Band</label>
                                <select name="band_selection" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 bg-white">
                                    <option value="" disabled selected>Pilih Band</option>
                                    <optgroup label="4G Bands">
                                        <option value="1">Band 1 (2100 MHz)</option>
                                        <option value="3">Band 3 (1800 MHz)</option>
                                        <option value="5">Band 5 (850 MHz)</option>
                                        <option value="7">Band 7 (2600 MHz)</option>
                                        <option value="8">Band 8 (900 MHz)</option>
                                        <option value="20">Band 20 (800 MHz)</option>
                                        <option value="28">Band 28 (700 MHz)</option>
                                        <option value="38">Band 38 (2600 MHz)</option>
                                        <option value="40">Band 40 (2300 MHz)</option>
                                        <option value="41">Band 41 (2500 MHz)</option>
                                    </optgroup>
                                    <optgroup label="5G Bands">
                                        <option value="n1">Band n1 (2100 MHz)</option>
                                        <option value="n3">Band n3 (1800 MHz)</option>
                                        <option value="n5">Band n5 (850 MHz)</option>
                                        <option value="n7">Band n7 (2600 MHz)</option>
                                        <option value="n8">Band n8 (900 MHz)</option>
                                        <option value="n28">Band n28 (700 MHz)</option>
                                        <option value="n40">Band n40 (2300 MHz)</option>
                                        <option value="n41">Band n41 (2500 MHz)</option>
                                        <option value="n77">Band n77 (3700 MHz)</option>
                                        <option value="n78">Band n78 (3500 MHz)</option>
                                        <option value="n79">Band n79 (4500 MHz)</option>
                                    </optgroup>
                                    <optgroup label="Multiple Bands">
                                        <option value="1,3,8">Bands 1+3+8 (Combo)</option>
                                        <option value="1,3,40,41">Bands 1+3+40+41 (Combo)</option>
                                        <option value="n77,n78">5G Bands n77+n78 (Combo)</option>
                                        <option value="3,n78">4G+5G Band 3+n78 (Combo)</option>
                                    </optgroup>
                                </select>
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">Metode Lock</label>
                                <select name="command_type" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 bg-white">
                                    <option value="standard" selected>Metode Standard</option>
                                    <option value="qcrilhook">Metode QcrilHook</option>
                                    <option value="qcrilnr">Metode QcrilNR (5G)</option>
                                    <option value="alternative">Metode Alternatif</option>
                                    <option value="netmgr">Metode NetMgr</option>
                                    <option value="atcommand">Perintah AT</option>
                                    <option value="multiple_bands">Multiple Bands</option>
                                    <option value="direct_inject">Direct Inject</option>
                                    <option value="mediatek">Mediatek</option>
                                </select>
                            </div>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">Preset Provider</label>
                                <select name="provider_preset" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 bg-white">
                                    <option value="" selected disabled>Pilih Provider</option>
                                    <option value="telkomsel">Telkomsel</option>
                                    <option value="xl">XL Axiata</option>
                                    <option value="indosat">Indosat Ooredoo</option>
                                    <option value="tri">Tri Indonesia</option>
                                    <option value="smartfren">Smartfren</option>
                                </select>
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">Preferensi Jaringan</label>
                                <select name="network_preference" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 bg-white">
                                    <option value="" selected disabled>Pilih Preferensi</option>
                                    <option value="5g">5G/4G/3G/2G (Auto)</option>
                                    <option value="5g_standalone">5G SA Only</option>
                                    <option value="4g">4G/3G/2G (Auto)</option>
                                    <option value="4g_only">4G Only</option>
                                    <option value="3g">3G Preferred</option>
                                    <option value="3g_only">3G Only</option>
                                    <option value="2g">2G Only</option>
                                </select>
                            </div>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">Force 5G Mode</label>
                                <select name="force_5g_mode" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 bg-white">
                                    <option value="" selected disabled>Pilih Mode 5G</option>
                                    <option value="nsa">Force 5G NSA</option>
                                    <option value="sa">Force 5G SA</option>
                                    <option value="both">Enable Both NSA & SA</option>
                                </select>
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">EARFCN/NR-ARFCN</label>
                                <input type="text" name="earfcn_value" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500" placeholder="Opsional">
                            </div>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">Cell ID</label>
                                <input type="text" name="cell_id_value" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500" placeholder="Opsional">
                            </div>
                        </div>

                        <div class="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div class="flex items-center">
                                <input type="checkbox" name="set_network_pref" id="set_network_pref" class="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded">
                                <label for="set_network_pref" class="ml-2 block text-sm text-gray-700">Terapkan Preferensi Jaringan</label>
                            </div>
                            
                            <div class="flex items-center">
                                <input type="checkbox" name="set_earfcn" id="set_earfcn" class="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded">
                                <label for="set_earfcn" class="ml-2 block text-sm text-gray-700">Terapkan EARFCN/ARFCN</label>
                            </div>
                            
                            <div class="flex items-center">
                                <input type="checkbox" name="lock_cell_id" id="lock_cell_id" class="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded">
                                <label for="lock_cell_id" class="ml-2 block text-sm text-gray-700">Kunci ke Cell ID Spesifik</label>
                            </div>
                            
                            <div class="flex items-center">
                                <input type="checkbox" name="restart_radio" id="restart_radio" class="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded">
                                <label for="restart_radio" class="ml-2 block text-sm text-gray-700">Restart Radio Setelah Perubahan</label>
                            </div>
                            
                            <div class="flex items-center">
                                <input type="checkbox" name="enable_monitoring" id="enable_monitoring" class="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded">
                                <label for="enable_monitoring" class="ml-2 block text-sm text-gray-700">Aktifkan Monitoring Sinyal</label>
                            </div>
                        </div>

                        <div class="mt-6 flex flex-wrap gap-3">
                            <button type="submit" name="action" value="lock_band" class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                                <i class="fas fa-lock mr-2"></i> Kunci Band
                            </button>
                            <button type="submit" name="action" value="unlock_band" class="inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md shadow-sm text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                                <i class="fas fa-unlock mr-2"></i> Buka Kunci Band
                            </button>
                            <button type="submit" name="action" value="get_network_info" class="inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md shadow-sm text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                                <i class="fas fa-info-circle mr-2"></i> Info Jaringan
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Tab: Modem Control -->
            <div id="tab-modem-control" class="tab-content">
                <div class="card bg-white p-6 mb-6 rounded-lg">
                    <div class="flex items-center mb-4">
                        <i class="fas fa-microchip text-indigo-600 text-xl mr-2"></i>
                        <h2 class="text-xl font-semibold text-gray-800">Kontrol Modem Lanjutan</h2>
                    </div>
                    <p class="text-gray-600 mb-6">Akses ke fungsi tingkat rendah modem perangkat.</p>
                    
                    <form action="" method="post" class="space-y-4">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">Pilih Perintah</label>
                                <select name="modem_command" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 bg-white">
                                    <option value="" disabled selected>Pilih Perintah</option>
                                    <option value="reset_modem">Reset Modem</option>
                                    <option value="force_reconnect">Paksa Koneksi Ulang</option>
                                    <option value="clear_radio_logs">Bersihkan Log Radio</option>
                                    <option value="modem_diagnostics">Diagnosa Modem</option>
                                    <option value="network_logging">Log Info Jaringan</option>
                                    <option value="set_fast_dormancy">Set Fast Dormancy</option>
                                    <option value="set_data_roaming">Set Data Roaming</option>
                                </select>
                            </div>
                            
                            <div class="space-y-3">
                                <div class="flex items-center">
                                    <input type="checkbox" name="fast_dormancy" id="fast_dormancy" class="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded">
                                    <label for="fast_dormancy" class="ml-2 block text-sm text-gray-700">Aktifkan Fast Dormancy</label>
                                </div>
                                
                                <div class="flex items-center">
                                    <input type="checkbox" name="data_roaming" id="data_roaming" class="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded">
                                    <label for="data_roaming" class="ml-2 block text-sm text-gray-700">Aktifkan Data Roaming</label>
                                </div>
                            </div>
                        </div>

                        <div class="mt-6">
                            <button type="submit" name="action" value="advanced_modem_control" class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                                <i class="fas fa-play mr-2"></i> Jalankan Perintah
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Tab: Kernel Tweaks -->
            <div id="tab-kernel-tweaks" class="tab-content">
                <div class="card bg-white p-6 mb-6 rounded-lg">
                    <div class="flex items-center mb-4">
                        <i class="fas fa-cogs text-indigo-600 text-xl mr-2"></i>
                        <h2 class="text-xl font-semibold text-gray-800">Tweaks Kernel</h2>
                    </div>
                    <p class="text-gray-600 mb-6">Optimalkan pengaturan kernel untuk performa jaringan yang lebih baik.</p>
                    
                    <form action="" method="post" class="space-y-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Pilih Tweak</label>
                            <select name="tweak_type" id="tweak_type_select" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 bg-white">
                                <option value="" disabled selected>Pilih Tweak</option>
                                <option value="tcp_optimize">Optimasi TCP</option>
                                <option value="network_buffer">Tingkatkan Buffer Jaringan</option>
                                <option value="dns_optimize">Optimasi DNS (Google)</option>
                                <option value="cloudflare_dns">DNS Cloudflare (1.1.1.1)</option>
                                <option value="quad9_dns">DNS Quad9 (9.9.9.9)</option>
                                <option value="custom_dns">DNS Kustom</option>
                                <option value="reset_tweaks">Reset Semua Tweaks</option>
                            </select>
                        </div>

                        <div id="custom_dns_fields" class="hidden grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">DNS Utama</label>
                                <input type="text" name="primary_dns" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500" placeholder="8.8.8.8">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">DNS Sekunder</label>
                                <input type="text" name="secondary_dns" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500" placeholder="8.8.4.4">
                            </div>
                        </div>

                        <div class="mt-6">
                            <button type="submit" name="action" value="kernel_tweaks" class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                                <i class="fas fa-bolt mr-2"></i> Terapkan Tweak
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Tab: Radio Control -->
            <div id="tab-radio-control" class="tab-content">
                <div class="card bg-white p-6 mb-6 rounded-lg">
                    <div class="flex items-center mb-4">
                        <i class="fas fa-broadcast-tower text-indigo-600 text-xl mr-2"></i>
                        <h2 class="text-xl font-semibold text-gray-800">Pengaturan Radio</h2>
                    </div>
                    <p class="text-gray-600 mb-6">Kontrol radio perangkat (WiFi, Bluetooth, Seluler).</p>
                    
                    <form action="" method="post" class="space-y-4">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <h3 class="text-lg font-medium text-gray-800 mb-3">Status Radio</h3>
                                <div class="space-y-3">
                                    <div class="flex items-center">
                                        <input type="checkbox" name="bluetooth_control" id="bluetooth_control" class="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded" <?php echo shell_exec("su -c 'svc bluetooth status'") === 'enabled' ? 'checked' : ''; ?>>
                                        <label for="bluetooth_control" class="ml-2 block text-sm text-gray-700">Bluetooth</label>
                                    </div>
                                    <div class="flex items-center">
                                        <input type="checkbox" name="wifi_control" id="wifi_control" class="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded" <?php echo shell_exec("su -c 'svc wifi status'") === 'enabled' ? 'checked' : ''; ?>>
                                        <label for="wifi_control" class="ml-2 block text-sm text-gray-700">WiFi</label>
                                    </div>
                                    <div class="flex items-center">
                                        <input type="checkbox" name="data_control" id="data_control" class="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded" <?php echo shell_exec("su -c 'svc data status'") === 'enabled' ? 'checked' : ''; ?>>
                                        <label for="data_control" class="ml-2 block text-sm text-gray-700">Data Seluler</label>
                                    </div>
                                </div>
                            </div>
                            
                            <div>
                                <h3 class="text-lg font-medium text-gray-800 mb-3">Mode Pesawat</h3>
                                <div class="space-y-3">
                                    <div class="flex items-center">
                                        <input type="checkbox" name="airplane_mode" id="airplane_mode" class="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded" <?php echo shell_exec("su -c 'settings get global airplane_mode_on'") == 1 ? 'checked' : ''; ?>>
                                        <label for="airplane_mode" class="ml-2 block text-sm text-gray-700">Aktifkan Mode Pesawat</label>
                                    </div>
                                    
                                    <h4 class="text-md font-medium text-gray-700 mt-4 mb-2">Radios yang dinonaktifkan:</h4>
                                    <?php $disabled_radios = explode(',', trim(shell_exec("su -c 'settings get global airplane_mode_radios'"))); ?>
                                    <div class="flex items-center">
                                        <input type="checkbox" name="airplane_cell" id="airplane_cell" class="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded" <?php echo in_array('cell', $disabled_radios) ? 'checked' : ''; ?>>
                                        <label for="airplane_cell" class="ml-2 block text-sm text-gray-700">Seluler</label>
                                    </div>
                                    <div class="flex items-center">
                                        <input type="checkbox" name="airplane_wifi" id="airplane_wifi" class="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded" <?php echo in_array('wifi', $disabled_radios) ? 'checked' : ''; ?>>
                                        <label for="airplane_wifi" class="ml-2 block text-sm text-gray-700">WiFi</label>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="mt-6">
                            <button type="submit" name="action" value="update_radios" class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                                <i class="fas fa-save mr-2"></i> Simpan Pengaturan
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Tab switching function
        function switchTab(tabId) {
            // Hide all tab contents
            document.querySelectorAll('.tab-content').forEach(content => {
                content.classList.remove('active');
            });
            
            // Show selected tab content
            document.getElementById(tabId).classList.add('active');
            
            // Update active tab styling
            document.querySelectorAll('.tab-button').forEach(btn => {
                btn.classList.remove('active', 'border-indigo-600', 'text-indigo-600');
                btn.classList.add('border-transparent');
            });
            
            // Find the button that corresponds to this tab and activate it
            const buttons = document.querySelectorAll('.tab-button');
            buttons.forEach(button => {
                if (button.getAttribute('onclick').includes(tabId)) {
                    button.classList.add('active', 'border-indigo-600', 'text-indigo-600');
                    button.classList.remove('border-transparent');
                }
            });
        }
        
        // Show custom DNS fields when selected
        document.getElementById('tweak_type_select').addEventListener('change', function() {
            const customDnsFields = document.getElementById('custom_dns_fields');
            if (this.value === 'custom_dns') {
                customDnsFields.classList.remove('hidden');
            } else {
                customDnsFields.classList.add('hidden');
            }
        });
        
        // Initialize first tab as active
        document.addEventListener('DOMContentLoaded', function() {
            switchTab('tab-lock-band');
        });
    </script>
</body>
</html>