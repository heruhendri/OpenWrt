<?php
session_start();

// Load credentials
$credentials = include 'credentials.php';
$stored_username = $credentials['username'];
$stored_hashed_password = $credentials['hashed_password'];

$config_file = '/data/adb/php7/files/www/auth/config.json';
if (!file_exists($config_file)) {
    die('Error: Configuration file not found.');
}
$config = json_decode(file_get_contents($config_file), true);

define('LOGIN_ENABLED', $config['LOGIN_ENABLED']);

if (!LOGIN_ENABLED) {
    $_SESSION['login_disabled'] = true;
}

// Remember Me functionality
if (isset($_COOKIE['remember_me']) && !isset($_SESSION['user_id'])) {
    $_SESSION['user_id'] = $_COOKIE['remember_me'];
    $_SESSION['username'] = $stored_username;
}

// Redirect if already logged in
if (isset($_SESSION['user_id'])) {
    header("Location: /");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $remember = isset($_POST['remember']);

    if ($username === $stored_username && password_verify($password, $stored_hashed_password)) {
        $_SESSION['user_id'] = session_id();
        $_SESSION['username'] = $username;

        header("Location: /");
        exit;
    } else {
        $error = 'Invalid username or password.';
    }
}
?>
<!DOCTYPE html><html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#5e72e4">
    <link rel="icon" href="../webui/assets/luci.ico" type="image/x-icon">
    <title>Login</title>
    <style>
.iconamoon--lock-fill {
  display: inline-block;
  width: 16.5px;
  height: 26px;
  --svg: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%3E%3Cpath fill='%23000' fill-rule='evenodd' d='M9 7a3 3 0 1 1 6 0v2H9zM7 9V7a5 5 0 0 1 10 0v2h2a1 1 0 0 1 1 1v9a3 3 0 0 1-3 3H7a3 3 0 0 1-3-3v-9a1 1 0 0 1 1-1zm6 6.5a1.5 1.5 0 0 1 1.5-1.5h.01a1.5 1.5 0 0 1 1.5 1.5v.01a1.5 1.5 0 0 1-1.5 1.5h-.01a1.5 1.5 0 0 1-1.5-1.5z' clip-rule='evenodd'/%3E%3C/svg%3E");
  background-color: currentColor;
  -webkit-mask-image: var(--svg);
  mask-image: var(--svg);
  -webkit-mask-repeat: no-repeat;
  mask-repeat: no-repeat;
  -webkit-mask-size: 100% 100%;
  mask-size: 100% 100%;
}
.fa6-solid--user {
  display: inline-block;
  width: 14px;
  height: 14px;
  --svg: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 448 512'%3E%3Cpath fill='%23000' d='M224 256a128 128 0 1 0 0-256a128 128 0 1 0 0 256m-45.7 48C79.8 304 0 383.8 0 482.3C0 498.7 13.3 512 29.7 512h388.6c16.4 0 29.7-13.3 29.7-29.7c0-98.5-79.8-178.3-178.3-178.3z'/%3E%3C/svg%3E");
  background-color: currentColor;
  -webkit-mask-image: var(--svg);
  mask-image: var(--svg);
  -webkit-mask-repeat: no-repeat;
  mask-repeat: no-repeat;
  -webkit-mask-size: 100% 100%;
  mask-size: 100% 100%;
}
@font-face {
  font-family: 'LemonMilkProRegular';
  src: url('../webui/fonts/LemonMilkProRegular.otf') format('opentype');
}
* {
  -webkit-user-select: none; /* Safari */
  -moz-user-select: none; /* Firefox */
  -ms-user-select: none; /* Internet Explorer/Edge */
  user-select: none; /* Standard */
  -webkit-tap-highlight-color: transparent; /* Hilangkan efek tap di mobile */
}
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
    * {
    -webkit-user-select: none; /* Safari */
    -moz-user-select: none; /* Firefox */
    -ms-user-select: none; /* Internet Explorer/Edge */
    user-select: none; /* Standard */
    -webkit-tap-highlight-color: transparent; /* Hilangkan efek tap di mobile */
}
    body {
        background: url('./assets/background.jpg') no-repeat center center fixed;
        background-size: cover;
        font-family: 'LemonMilkProRegular';
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
    }

.login-container {
    position: absolute;
    top: 45%;
    left: 50%;
    transform: translate(-50%, -50%);
}

    .login-box {
        background-color: background: rgba(255, 255, 255, 0.05);
        border: 1px solid rgba(255, 255, 255, 0.3);
        backdrop-filter: blur(3px);
        padding: 35px;
        border-radius: 8px;
        box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
        width: 320px;
    }

    h2 {
        text-align: center;
        margin-bottom: 20px;
        color: #fff;
    }

    .input-group {
        margin-bottom: 12px;
        position: relative;
    }

    .input-group label {
        font-size: 14px;
        margin-left: 2px;
        color: #fff;
    }

    .input-group input {
        width: 100%;
        padding: 10px 10px 10px 30px;
        font-size: 14px;
        border: 1px solid rgba(255, 255, 255, 0.3);
        border-radius: 16px;
        margin-top: 5px;
        text-align: left;
        background-color: transparent;
        color: #fff;
    }

    .input-group input:focus {
        outline: none;
        border-color: #4a90e2;
    }

    .input-group i {
        position: absolute;
        left: 12px;
        top: 70%;
        transform: translateY(-50%);
        color: #fff;
        font-size: 14px;
    }

    .options {
        display: flex;
        color: #fff;
        justify-content: space-between;
        align-items: center;
        font-size: 12px;
        margin-top: 10px;
        margin-bottom: 25px;
    }
    
    /* Styling checkbox */
.options label {
    display: flex;
    align-items: center;
    cursor: pointer;
}

.options input[type="checkbox"] {
    appearance: none;
    width: 13px;
    height: 13px;
    border: 1.5px solid #fff;
    border-radius: 4px;
    position: relative;
    margin-right: 8px;
    background: transparent;
    cursor: pointer;
}

.options input[type="checkbox"]:checked {
    background-color: transparent;
    border-color: #4a90e2;
}

.options input[type="checkbox"]::before {
    content: '✔';
    font-size: 14px;
    color: white;
    background: transparent;
    display: none;
    position: absolute;
    left: 1.5px;
    top: -7px;
}


.options input[type="checkbox"]:checked::before {
    display: block;
}

    .btn-login {
        width: 50%;
        margin: 0 auto;
        display: block;
        padding: 10px;
        background-color: #4a90e2;
        font-family: 'LemonMilkProRegular';
        font-weight: 500;
        color: #fff;
        border: none;
        border-radius: 16px;
        cursor: pointer;
        font-size: 16px;
    }

    .btn-login:hover {
        background-color: #357abd;
    }

    .forgot-password {
        text-align: center;
        margin-top: 10px;
    }

    .forgot-password a {
        color: #4a90e2;
        text-decoration: none;
        font-size: 14px;
    }

    .forgot-password a:hover {
        text-decoration: underline;
    }
</style>
</head>
<body>
    <div class="login-container">
        <div class="login-box">
            <h2>Hello, Welcome!</h2>
            <form method="POST">
                <div class="input-group">
                    <i class="fa6-solid--user"></i>
                    <label for="username">Username</label>
                    <input type="text" name="username" required>
                </div>
                <div class="input-group">
                    <i class="iconamoon--lock-fill"></i>
                    <label for="password">Password</label>
                    <input type="password" name="password" id="password" required>
                </div>
                <div class="options">
                    <label><input type="checkbox" id="showPassword"> Show Password</label>
                </div>
                <button type="submit" class="btn-login">Login</button>
                <?php if (isset($error)) echo "<p style='color: #d9534f; text-align: center; margin-top: 10px; margin-bottom: -20px; font-size: 12px;' class='error'>$error</p>"; ?>
            </form>
        </div>
    </div>
    <script>
        document.getElementById('showPassword').addEventListener('change', function() {
            const passwordField = document.getElementById('password');
            passwordField.type = this.checked ? 'text' : 'password';
        });
    </script>
</body>
</html>