<script src="js/index.js" async></script>
<script src="js/openclash.js" async></script>
