# Behavior: classical
# Credit : reyre, aiqyr, malikshi, hagezi, dantewrt, zhapers, helmiau and another much sources from github
# blackmatrix7/ios_rule_script/tree/master/rule/Clash
# AdGuard for Adblock

# Last Edited By Qyubisanz14 2025