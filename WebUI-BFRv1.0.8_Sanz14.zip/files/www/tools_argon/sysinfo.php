<?php
// System Information
$deviceName = trim(shell_exec('getprop ro.product.manufacturer')) . ' ' . 
              trim(shell_exec('getprop ro.product.model')) . ' (' . 
              trim(shell_exec('getprop ro.product.device')) . ')';
$os = trim(shell_exec('getprop ro.build.version.release'));

// Uptime
$uptime = floatval(explode(' ', shell_exec('cat /proc/uptime'))[0]);
$days = floor($uptime / 86400);
$hours = floor(($uptime % 86400) / 3600);
$minutes = floor(($uptime % 3600) / 60);
$uptimeFormatted = "$days days, $hours hour, $minutes minutes";

// Battery Information
$batteryInfo = shell_exec('dumpsys battery');
preg_match('/temperature:\s(\d+)/', $batteryInfo, $tempMatches);
preg_match('/level:\s(\d+)/', $batteryInfo, $levelMatches);
preg_match('/AC\s*powered:\s*(true|false)/', $batteryInfo, $chargingMatches);

$temperatureFormatted = isset($tempMatches[1]) ? number_format($tempMatches[1] / 10, 1) : 'N/A';
$level = $levelMatches[1] ?? 'N/A';
$chargingStatus = (isset($chargingMatches[1]) && strtolower($chargingMatches[1]) === 'true') ? 'Charging' : 'Discharging';
$batteryCurrent = trim(shell_exec('cat /sys/class/power_supply/battery/current_now')) ?: 'N/A';
$batteryVoltageRaw = trim(shell_exec('cat /sys/class/power_supply/battery/voltage_now'));
$batteryVoltage = $batteryVoltageRaw ? number_format($batteryVoltageRaw / 1000000, 2) . 'V' : 'N/A';

// Network Information
$networkInterfaces = [];
$interfaces = explode("\n", trim(shell_exec("ls /sys/class/net")));
foreach ($interfaces as $interface) {
    if (empty($interface)) continue;
    
    $ip = trim(shell_exec("ip addr show $interface | grep 'inet ' | awk '{print \$2}' | head -n1"));
    $rx = trim(shell_exec("cat /sys/class/net/$interface/statistics/rx_bytes"));
    $tx = trim(shell_exec("cat /sys/class/net/$interface/statistics/tx_bytes"));
    
    if ($ip) {
        $received = $rx >= 1073741824 ? round($rx / 1073741824, 2) . ' GB' : round($rx / 1048576, 2) . ' MB';
        $transmitted = $tx >= 1073741824 ? round($tx / 1073741824, 2) . ' GB' : round($tx / 1048576, 2) . ' MB';
        
        $networkInterfaces[] = [
            'name' => $interface,
            'ip' => $ip,
            'received' => $received,
            'transmitted' => $transmitted
        ];
    }
}

// CPU Information
$cpuInfo = shell_exec('cat /proc/cpuinfo');
preg_match('/Hardware\s+:\s+([^\n]+)/', $cpuInfo, $hardware);
preg_match_all('/processor\s+/', $cpuInfo, $processors);
$hardwareResult = isset($hardware[1]) ? trim(preg_replace('/^(Qualcomm Technologies, Inc|MediaTek|Broadcom)\s*/', '', $hardware[1])) : 'Unknown';
$coreCount = isset($processors[0]) ? count($processors[0]) : 'Unknown';

// SIM Information
$simOperator = trim(shell_exec('getprop gsm.sim.operator.alpha')) ?: 'N/A';
$simQuality = shell_exec('dumpsys telephony.registry | grep -E "mSignalStrength="');
$signalData = [
    'rssi' => 'N/A',
    'rsrp' => 'N/A',
    'rsrq' => 'N/A',
    'rssnr' => 'N/A'
];

if (preg_match_all('/CellSignalStrengthLte: rssi=([-\d]+) rsrp=([-\d]+) rsrq=([-\d]+) rssnr=([-\d]+)/', $simQuality, $matches, PREG_SET_ORDER)) {
    $signalData = [
        'rssi' => $matches[0][1] ?? 'N/A',
        'rsrp' => $matches[0][2] ?? 'N/A',
        'rsrq' => $matches[0][3] ?? 'N/A',
        'rssnr' => $matches[0][4] ?? 'N/A'
    ];
}

// GPU Information
$gpuModel = trim(shell_exec("cat /sys/kernel/gpu/gpu_model 2>/dev/null")) ?: 'Unknown';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>System Dashboard</title>
    <link rel="stylesheet" href="css&fonts/sysinfo.css">
    <style>
        .dashboard-container {
            flex-direction: column;
            justify-content: center;
            align-items: center;
            padding: 10px;
        }
    </style>
</head>
<body>
    <header>
        <div class="new-container">
            <p>Status</p>
        </div>
    </header>

    <!-- Memory Section -->
    <div class="container">
        <div class="chart" id="memoryChart" data-label="Memory"></div>
        <div class="details">
            <div class="progress-bar">
                <div class="bar">
                    <div class="bar-inner"></div>
                </div>
                <div class="bar-label">
                    <span>
                        <b style="margin-right: 40px;">RAM</b>
                        <span class="used-memory-percent"></span> 
                        <span class="total-memory"></span>
                    </span>
                </div>
            </div>
            <div class="progress-bar">
                <div class="bar">
                    <div class="bar-inner"></div>
                </div>
                <div class="bar-label">
                    <span>
                        <b style="margin-right: 38px;">Swap</b>
                        <span class="used-swap-percent"></span>
                        <span class="total-swap"></span>
                    </span>
                </div>
            </div>
            <div class="extra-info">
                <span style="flex: 1; text-align: left;">SwapCached <span class="total-swapcache"></span></span>
                <span style="flex: 1; text-align: center;">Dirty <span class="total-dirty"></span></span>
            </div>
        </div>
    </div>

    <!-- GPU Section -->
    <div class="gpu-container">
        <div class="gpu-chart" id="gpuChart" data-label="GPU"></div>
        <div class="gpu-load">
            <p><b class="gpu-freq">---- MHz</b></p>
            <p class="gpu-loads">Load %</p>
            <p><?= htmlspecialchars($gpuModel) ?></p>
        </div>
    </div>

    <!-- System Info Section -->
    <div class="dashboard-container">
        <div class="row">
            <div class="column sim-info">
                <div class="section-title">SYSTEM</div>
                <div>
                    <span class="raphael--android"></span>
                    <span class="status-value">Android <?= htmlspecialchars($os) ?></span>
                </div>
                <div>
                    <span class="ph--clock-countdown-fill"></span>
                    <span class="status-value"><?= htmlspecialchars($uptimeFormatted) ?></span>
                </div>
                <div>
                    <span class="ic--twotone-phone-iphone"></span>
                    <span class="status-value"><?= htmlspecialchars($deviceName) ?></span>
                </div>
            </div>
            <div class="divider"></div>
            <div class="column">
                <div class="section-title">BATTERY</div>
                <div>
                    <span class="fluent--usb-plug-20-filled"></span>
                    <span class="status-value">
                        <?= htmlspecialchars($chargingStatus) ?>&nbsp;(<?= htmlspecialchars($batteryCurrent) ?>&nbsp;µA)
                    </span>
                </div>
                <div>
                    <span class="tabler--battery-vertical-2-filled"></span>
                    <span class="status-value">
                        <?= htmlspecialchars($level) ?>% (<?= htmlspecialchars($batteryVoltage) ?>)
                    </span>
                </div>
                <div>
                    <span class="mdi--fire"></span>
                    <span class="status-value"><?= htmlspecialchars($temperatureFormatted) ?>°C</span>
                </div>
            </div>
        </div>
    </div>

    <!-- CPU and SIM Section -->
    <div class="dashboard-container">
        <div class="row">
            <div class="column sim-info">
                <div class="section-title">SIM</div>
                <p>Operator: <?= htmlspecialchars($simOperator) ?></p>
                <p>RSSI: <?= htmlspecialchars($signalData['rssi']) ?></p>
                <p>RSRP: <?= htmlspecialchars($signalData['rsrp']) ?></p>
                <p>RSRQ: <?= htmlspecialchars($signalData['rsrq']) ?></p>
                <p>SINR: <?= htmlspecialchars($signalData['rssnr']) ?></p>
            </div>
            <div class="divider"></div>
            <div class="column">
                <div class="section-title">CPU</div>
                <div class="cpu-container">
                    <div class="cpu-bar">
                        <?php for ($i = 0; $i < 15; $i++): ?>
                            <div class="low" style="height: 0%"></div>
                        <?php endfor; ?>
                    </div>
                    <p class="cpu-info"><?= htmlspecialchars($hardwareResult) ?> (<?= htmlspecialchars($coreCount) ?>)</p>
                    <p class="cpu-load">Load %</p>
                </div>
            </div>
        </div>
        
        <!-- Network Table -->
        <div>
            <div class="network-title">Network</div>
            <table>
                <thead>
                    <tr>
                        <th>Interface</th>
                        <th>IP</th>
                        <th>Receive</th>
                        <th>Transmit</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($networkInterfaces as $interface): ?>
                        <tr>
                            <td><?= htmlspecialchars($interface['name']) ?></td>
                            <td><?= htmlspecialchars($interface['ip']) ?></td>
                            <td><?= htmlspecialchars($interface['received']) ?></td>
                            <td><?= htmlspecialchars($interface['transmitted']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        function updateMemoryStatus() {
            fetch('exec/helpers.php')
                .then(response => response.json())
                .then(data => {
                    // Update memory information
                    if (document.querySelector('.total-memory')) {
                        document.querySelector('.total-memory').textContent = `(${data.total_memory})`;
                    }
                    
                    if (document.querySelector('.used-memory-percent')) {
                        document.querySelector('.used-memory-percent').textContent = `${data.used_memory_percent}%`;
                    }
                    
                    if (document.querySelector('.total-swap')) {
                        document.querySelector('.total-swap').textContent = `(${data.total_swap})`;
                    }
                    
                    if (document.querySelector('.used-swap-percent')) {
                        document.querySelector('.used-swap-percent').textContent = `${data.used_swap_percent}%`;
                    }
                    
                    if (document.querySelector('.total-swapcache')) {
                        document.querySelector('.total-swapcache').textContent = data.total_swapcache;
                    }
                    
                    if (document.querySelector('.total-dirty')) {
                        document.querySelector('.total-dirty').textContent = data.total_dirty;
                    }
                    
                    // Update GPU information
                    if (document.querySelector('.gpu-freq')) {
                        document.querySelector('.gpu-freq').textContent = `${data.gpuFreq} MHz`;
                    }
                    
                    if (document.querySelector('.gpu-loads')) {
                        document.querySelector('.gpu-loads').textContent = `Load: ${data.gpuLoad}%`;
                    }
                    
                    // Update CPU information
                    if (document.querySelector('.cpu-load')) {
                        document.querySelector('.cpu-load').textContent = `Load: ${data.active}%`;
                    }
                    
                    // Update charts
                    const isDarkMode = window.matchMedia('(prefers-color-scheme: dark)').matches;
                    const memoryChart = document.querySelector('#memoryChart');
                    const gpuChart = document.querySelector('#gpuChart');
                    
                    memoryChart.style.background = `conic-gradient(${isDarkMode ? '#4c96ff' : '#4c96ff'} 0% ${data.used_memory_percent}%, ${isDarkMode ? '#555555' : '#e6e6e6'} ${data.used_memory_percent}% 100%)`;
                    gpuChart.style.background = `conic-gradient(${isDarkMode ? '#ff9f43' : '#ff9f43'} 0% ${data.gpuLoad}%, ${isDarkMode ? '#555555' : '#e6e6e6'} ${data.gpuLoad}% 100%)`;
                    
                    // Update CPU bars
                    const barContainer = document.querySelector('.cpu-bar');
                    const bars = Array.from(barContainer.children);
                    
                    if (bars.length >= 10) {
                        barContainer.removeChild(bars[0]);
                    }
                    
                    const newBar = document.createElement('div');
                    newBar.style.height = `${data.active}%`;
                    
                    if (data.active <= 25) {
                        newBar.className = 'low';
                    } else if (data.active <= 50) {
                        newBar.className = 'medium';
                    } else if (data.active <= 75) {
                        newBar.className = 'high';
                    } else {
                        newBar.className = 'critical';
                    }
                    
                    barContainer.appendChild(newBar);
                    
                    // Update progress bars
                    const barElements = document.querySelectorAll('.bar-inner');
                    if (barElements.length >= 2) {
                        barElements[0].style.width = `${data.used_memory_percent}%`;
                        barElements[1].style.width = `${data.used_swap_percent}%`;
                    }
                })
                .catch(error => console.error('Error:', error));
        }
        
        setInterval(updateMemoryStatus, 1500);
        updateMemoryStatus(); // Initial call
    </script>
</body>
</html>