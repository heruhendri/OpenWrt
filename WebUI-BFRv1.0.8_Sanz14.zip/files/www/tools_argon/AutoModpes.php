<?php
// ==============================================
// CONFIGURATION EDITOR - SINGLE FILE PHP VERSION
// ==============================================

$configPath = '/data/adb/modules/modpes/config.ini';
$message = '';
$error = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Get and validate form data
        $enabled = isset($_POST['enabled']) ? 'true' : 'false';
        $useCmd = isset($_POST['useCmd']) ? 'true' : 'false';
        $timeout = max(1, min(60, intval($_POST['timeout'] ?? 5)));
        $interval = max(1, min(3600, intval($_POST['interval'] ?? 10)));
        $maxRetry = max(0, min(10, intval($_POST['maxRetry'] ?? 3)));
        $pingTarget = htmlspecialchars($_POST['pingTarget'] ?? 'ava.game.naver.com');
        $radios = $_POST['radios'] ?? ['cell', 'bluetooth', 'nfc', 'wimax'];
        
        // Generate config content
        $configContent = "ENABLED=$enabled\n";
        $configContent .= "USE_CMD=$useCmd\n";
        $configContent .= "TIMEOUT=$timeout\n";
        $configContent .= "INTERVAL=$interval\n";
        $configContent .= "MAX_RETRY=$maxRetry\n";
        $configContent .= "# Change Target ping with your BUG Host or IP Address\n";
        $configContent .= 'PING_TARGET="' . $pingTarget . "\"\n";
        $configContent .= 'AIRPLANE_MODE_RADIOS="' . implode(',', $radios) . "\"\n";
        
        // Save to file
        if (!file_exists(dirname($configPath))) {
            mkdir(dirname($configPath), 0755, true);
        }
        
        if (file_put_contents($configPath, $configContent) === false) {
            throw new Exception("Failed to write config file. Check permissions.");
        }
        
        $message = "Configuration saved successfully!";
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

// Read existing config
$configValues = [
    'ENABLED' => 'true',
    'USE_CMD' => 'true',
    'TIMEOUT' => '5',
    'INTERVAL' => '10',
    'MAX_RETRY' => '3',
    'PING_TARGET' => 'ava.game.naver.com',
    'AIRPLANE_MODE_RADIOS' => 'cell,bluetooth,nfc,wimax'
];

if (file_exists($configPath)) {
    $lines = file($configPath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos($line, '=') !== false) {
            list($key, $value) = explode('=', $line, 2);
            $key = trim($key);
            $value = trim($value);
            if (preg_match('/^"(.*)"$/', $value, $matches)) {
                $value = $matches[1];
            }
            if (array_key_exists($key, $configValues)) {
                $configValues[$key] = $value;
            }
        }
    }
}

$activeRadios = explode(',', $configValues['AIRPLANE_MODE_RADIOS']);
$radioOptions = ['cell', 'bluetooth', 'nfc', 'wimax', 'wifi', 'gps'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, user-scalable=no">
    <title>Auto Airplane Mode</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #6366f1;
            --secondary: #4f46e5;
            --dark: #111827;
            --darker: #0f172a;
            --light: #e2e8f0;
            --lighter: #f8fafc;
            --success: #22c55e;
            --danger: #ef4444;
            --warning: #f59e0b;
            --text-primary: #f3f4f6;
            --text-secondary: #d1d5db;
            --border-color: #374151;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            touch-action: manipulation;
            overflow: hidden;
            background-color: var(--darker);
            color: var(--text-primary);
            line-height: 1.6;
        }
        
        .container {
            max-width: 900px;
            margin: 2rem auto;
            padding: 1.5rem;
            background: var(--dark);
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            border: 1px solid var(--border-color);
        }
        
        header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid var(--border-color);
        }
        
        h1 {
            color: var(--primary);
            font-size: 1.8rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }
        
        .logo {
            color: var(--primary);
            font-size: 1.8rem;
        }
        
        .btn {
            padding: 0.6rem 1.2rem;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .btn-primary {
            background-color: var(--primary);
            color: white;
        }
        
        .btn-primary:hover {
            background-color: var(--secondary);
            transform: translateY(-2px);
        }
        
        .btn-outline {
            background: transparent;
            border: 1px solid var(--primary);
            color: var(--primary);
        }
        
        .btn-outline:hover {
            background-color: var(--primary);
            color: white;
        }
        
        .form-group {
            margin-bottom: 1.5rem;
        }
        
        .form-label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
            color: var(--text-primary);
        }
        
        .form-control {
            width: 100%;
            padding: 0.75rem 1rem;
            background-color: var(--darker);
            border: 1px solid var(--border-color);
            color: var(--text-primary);
            border-radius: 8px;
            font-size: 1rem;
            transition: border-color 0.3s;
        }
        
        .form-control:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.3);
        }
        
        .form-help {
            font-size: 0.85rem;
            color: var(--text-secondary);
            margin-top: 0.5rem;
        }
        
        .toggle-switch {
            position: relative;
            display: inline-block;
            width: 60px;
            height: 30px;
        }
        
        .toggle-switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }
        
        .slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #4b5563;
            transition: .4s;
            border-radius: 34px;
        }
        
        .slider:before {
            position: absolute;
            content: "";
            height: 22px;
            width: 22px;
            left: 4px;
            bottom: 4px;
            background-color: white;
            transition: .4s;
            border-radius: 50%;
        }
        
        input:checked + .slider {
            background-color: var(--primary);
        }
        
        input:checked + .slider:before {
            transform: translateX(30px);
        }
        
        .toggle-container {
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        
        .toggle-label {
            font-weight: 500;
            color: var(--text-primary);
        }
        
        .checkbox-group {
            display: flex;
            flex-wrap: wrap;
            gap: 1rem;
            margin-top: 0.5rem;
        }
        
        .checkbox-item {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            color: var(--text-primary);
        }
        
        .checkbox-item input[type="checkbox"] {
            width: 18px;
            height: 18px;
            accent-color: var(--primary);
        }
        
        .card {
            background: var(--dark);
            border-radius: 10px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            border: 1px solid var(--border-color);
        }
        
        .card-title {
            font-size: 1.2rem;
            margin-bottom: 1rem;
            color: var(--primary);
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }
        
        .footer {
            display: flex;
            justify-content: flex-end;
            gap: 1rem;
            margin-top: 2rem;
            padding-top: 1.5rem;
            border-top: 1px solid var(--border-color);
        }
        
        .toast {
            position: fixed;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
            background-color: var(--primary);
            background-color: green;
            color: white;
            padding: 12px 24px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
            z-index: 1000;
            opacity: 0;
            transition: opacity 0.3s ease;
        }
        
        .toast.show {
            opacity: 1;
        }
        
        .toast.error {
            background-color: var(--danger);
        }
        
        @media (max-width: 768px) {
            .container {
                margin: 1rem;
                padding: 1rem;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1><i class="fas fa-cog logo"></i> Auto Airplane Mode</h1>
        </header>
        
        <?php if ($message): ?>
        <div class="toast show"><?= htmlspecialchars($message) ?></div>
        <?php elseif ($error): ?>
        <div class="toast show error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        
        <form method="POST">
            <div class="card">
                <h2 class="card-title"><i class="fas fa-power-off"></i> Main Settings</h2>
                
                <div class="form-group">
                    <div class="toggle-container">
                        <label class="toggle-switch">
                            <input type="checkbox" id="enabled" name="enabled" <?= $configValues['ENABLED'] === 'true' ? 'checked' : '' ?>>
                            <span class="slider"></span>
                        </label>
                        <span class="toggle-label">Enabled</span>
                    </div>
                    <p class="form-help">Enable or disable the entire service</p>
                </div>
                
                <div class="form-group">
                    <div class="toggle-container">
                        <label class="toggle-switch">
                            <input type="checkbox" id="useCmd" name="useCmd" <?= $configValues['USE_CMD'] === 'true' ? 'checked' : '' ?>>
                            <span class="slider"></span>
                        </label>
                        <span class="toggle-label">Use CMD</span>
                    </div>
                    <p class="form-help">When enabled, uses Command instead of ActivityManager</p>
                </div>
            </div>
            
            <div class="card">
                <h2 class="card-title"><i class="fas fa-clock"></i> Timing Settings</h2>
                
                <div class="form-group">
                    <label for="timeout" class="form-label">Timeout (seconds)</label>
                    <input type="number" id="timeout" name="timeout" class="form-control" 
                           value="<?= htmlspecialchars($configValues['TIMEOUT']) ?>" min="1" max="60">
                    <p class="form-help">Maximum time to wait for a response</p>
                </div>
                
                <div class="form-group">
                    <label for="interval" class="form-label">Interval (seconds)</label>
                    <input type="number" id="interval" name="interval" class="form-control" 
                           value="<?= htmlspecialchars($configValues['INTERVAL']) ?>" min="1" max="3600">
                    <p class="form-help">Time between checks</p>
                </div>
                
                <div class="form-group">
                    <label for="maxRetry" class="form-label">Max Retry</label>
                    <input type="number" id="maxRetry" name="maxRetry" class="form-control" 
                           value="<?= htmlspecialchars($configValues['MAX_RETRY']) ?>" min="0" max="10">
                    <p class="form-help">Number of retry attempts</p>
                </div>
            </div>
            
            <div class="card">
                <h2 class="card-title"><i class="fas fa-network-wired"></i> Network Settings</h2>
                
                <div class="form-group">
                    <label for="pingTarget" class="form-label">Ping Target</label>
                    <input type="text" id="pingTarget" name="pingTarget" class="form-control" 
                           value="<?= htmlspecialchars($configValues['PING_TARGET']) ?>">
                    <p class="form-help">Host or IP address to ping for connectivity check</p>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Airplane Mode Radios</label>
                    <div class="checkbox-group">
                        <?php foreach ($radioOptions as $radio): ?>
                        <label class="checkbox-item">
                            <input type="checkbox" name="radios[]" value="<?= $radio ?>" 
                                  <?= in_array($radio, $activeRadios) ? 'checked' : '' ?>> 
                            <?= ucfirst($radio) ?>
                        </label>
                        <?php endforeach; ?>
                    </div>
                    <p class="form-help">Radios to disable when in airplane mode</p>
                </div>
            </div>
            
            <div class="footer">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> Save Configuration
                </button>
            </div>
        </form>
    </div>

    <script>
        // Auto-hide toast messages after 3 seconds
        setTimeout(() => {
            const toasts = document.querySelectorAll('.toast');
            toasts.forEach(toast => {
                toast.classList.remove('show');
            });
        }, 3000);
    </script>
</body>
</html>