php_data_dir="/data/adb/php7"

rm_data() {
    rm -rf ${php_data_dir}
}

rm_data